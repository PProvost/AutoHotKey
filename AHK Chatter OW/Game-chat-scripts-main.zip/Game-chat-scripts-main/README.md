# Game Chat Scripts & Auto AutoHotkey Script Writing Tool(AAHKSWT)
- A repo for in-game text chat scripts. Feel free to add any you think should be included.
- All scripts are meant for use with AHK(AutoHotkey)
- Each AASHKWT is game specific but feel free to request a game or edit the code to fit whatever you're working on!
